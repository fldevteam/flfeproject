/*! mygrunt - v1.0.0 - 2015-02-26 */var fname = "foo";
var sayHello = function(fname){
	return "Hello " + fname;
};var ftitle = "bar";
var sayBye = function(ftitle){
  return "Bye " + ftitle;
};